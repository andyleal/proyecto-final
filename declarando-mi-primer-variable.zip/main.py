edad = 22 #nombre=edad, valor -> 22
altura = 1.6
institucion = "Emtech" #nombre=insttucion, valor -> "Emtech"

nombre_amigo = "Juan Diego"
#1nombre_amigo = "Andrea Leal"
nombre_amigo2 = "Patricia"

print(nombre_amigo)
print(altura)
print(institucion)

print("Andrea Leal")
print("Emtech")
print(22)

edad = 20
nombre_amigo = "Leonardo Perez"

print(nombre_amigo)
print(edad)
